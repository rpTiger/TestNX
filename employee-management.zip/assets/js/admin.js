jQuery(document).ready(function($) {
    // Initialize DataTable with enhanced settings
    if ($('#employee-table').length && $('#employee-table tbody tr').length > 0) {
        $('#employee-table').DataTable({
            "pageLength": 25,
            "lengthMenu": [10, 25, 50, 100],
            "order": [[0, 'asc']],
            "language": {
                "search": "",
                "searchPlaceholder": "Search employees...",
                "lengthMenu": "Show _MENU_ entries",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                "infoEmpty": "Showing 0 to 0 of 0 entries",
                "infoFiltered": "(filtered from _MAX_ total entries)",
                "paginate": {
                    "first": '<i class="bi bi-chevron-double-left"></i>',
                    "last": '<i class="bi bi-chevron-double-right"></i>',
                    "next": '<i class="bi bi-chevron-right"></i>',
                    "previous": '<i class="bi bi-chevron-left"></i>'
                }
            },
            "dom": '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
                   '<"row"<"col-sm-12"tr>>' +
                   '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
            "responsive": true,
            "initComplete": function() {
                // Add custom styling to search box
                $('.dataTables_filter input').addClass('form-control');
                $('.dataTables_filter label').contents().filter(function() {
                    return this.nodeType === 3;
                }).remove();
                $('.dataTables_filter label').prepend('<i class="bi bi-search me-2 text-muted"></i>');
                
                // Add custom styling to length menu
                $('.dataTables_length select').addClass('form-select');
            }
        });
    }
    
    // File upload drag & drop functionality
    const fileUploadArea = $('.file-upload-area');
    const fileInput = $('#csv_file');
    const fileNameDisplay = $('#file-name');
    
    if (fileUploadArea.length && fileInput.length) {
        // Click to upload
        fileUploadArea.on('click', function(e) {
            if (!$(e.target).is('input')) {
                fileInput.click();
            }
        });
        
        // File selection handler
        fileInput.on('change', function(e) {
            if (this.files.length > 0) {
                const fileName = this.files[0].name;
                fileNameDisplay.html('<i class="bi bi-file-earmark-text me-1"></i>' + fileName);
                fileNameDisplay.show();
                fileUploadArea.addClass('border-primary').removeClass('border');
            }
        });
        
        // Drag & drop events
        fileUploadArea.on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('dragover border-primary');
        });
        
        fileUploadArea.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover border-primary');
        });
        
        fileUploadArea.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover border-primary');
            
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                fileInput[0].files = files;
                const fileName = files[0].name;
                fileNameDisplay.html('<i class="bi bi-file-earmark-text me-1"></i>' + fileName);
                fileNameDisplay.show();
                $(this).addClass('border-primary').removeClass('border');
            }
        });
    }
    
    // Form validation and submission
    $('form.needs-validation').on('submit', function(e) {
        if (!this.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        // Check file extension
        const fileInput = document.getElementById('csv_file');
        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            const fileExt = fileName.split('.').pop().toLowerCase();
            
            if (fileExt !== 'csv') {
                alert('❌ Please select a CSV file.');
                e.preventDefault();
                e.stopPropagation();
                return;
            }
        } else {
            alert('❌ Please select a CSV file to upload.');
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        
        // Confirm before replacing all data
        if (!confirm('⚠️ IMPORTANT: This will DELETE ALL existing employee data and replace it with the CSV file.\n\nAre you sure you want to continue?')) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        
        $(this).addClass('was-validated');
        
        // Show loading overlay
        const loadingOverlay = $(
            '<div id="ems-loading-overlay" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.97);z-index:9999;display:flex;justify-content:center;align-items:center;flex-direction:column;">' +
            '  <div class="spinner-border text-primary" style="width:4rem;height:4rem;">' +
            '    <span class="visually-hidden">Loading...</span>' +
            '  </div>' +
            '  <div class="mt-4 text-center" style="max-width:400px;">' +
            '    <h4 class="fw-bold mb-3 text-dark">Processing CSV Import</h4>' +
            '    <p class="text-muted mb-2">Importing employee data. This may take a moment for large files.</p>' +
            '    <div class="progress mt-3" style="height:6px;">' +
            '      <div class="progress-bar progress-bar-striped progress-bar-animated" style="width:45%"></div>' +
            '    </div>' +
            '  </div>' +
            '</div>'
        );
        
        $('body').append(loadingOverlay);
        
        // Simulate progress animation
        let progress = 45;
        const progressInterval = setInterval(() => {
            progress += Math.random() * 5;
            if (progress > 90) {
                progress = 90;
            }
            $('#ems-loading-overlay .progress-bar').css('width', progress + '%');
        }, 300);
        
        // Clear interval when page loads (safety)
        setTimeout(() => {
            clearInterval(progressInterval);
        }, 30000);
    });
    
    // Remove loading overlay on page load (in case of errors)
    $('#ems-loading-overlay').remove();
    
    // Refresh table button
    $('#refresh-table').on('click', function() {
        const $btn = $(this);
        const originalHtml = $btn.html();
        
        $btn.html('<i class="bi bi-arrow-clockwise me-1"></i> Refreshing...');
        $btn.prop('disabled', true);
        
        setTimeout(() => {
            window.location.reload();
        }, 500);
    });
    
    // Print table button
    $('#print-table').on('click', function(e) {
        e.preventDefault();
        
        // Store original DataTable state
        const table = $('#employee-table').DataTable();
        const originalSettings = $.extend(true, {}, table.settings()[0]);
        
        // Hide unnecessary elements for printing
        $('.card-header .btn, .dataTables_filter, .dataTables_length, .dataTables_paginate').hide();
        
        // Trigger print
        window.print();
        
        // Restore original state after a delay
        setTimeout(() => {
            $('.card-header .btn, .dataTables_filter, .dataTables_length, .dataTables_paginate').show();
            table.destroy();
            $('#employee-table').DataTable(originalSettings.oInit);
        }, 500);
    });
    
    // Sort buttons
    $('[data-sort]').on('click', function() {
        const sortOrder = $(this).data('sort');
        const $buttons = $('[data-sort]');
        
        $buttons.removeClass('active');
        $(this).addClass('active');
        
        if ($('#employee-table').DataTable()) {
            const table = $('#employee-table').DataTable();
            table.order([1, sortOrder]).draw();
        }
    });
    
    // Auto-hide alerts after 8 seconds
    setTimeout(() => {
        $('.notice.is-dismissible').fadeOut('slow', function() {
            $(this).remove();
        });
    }, 8000);
    
    // Smooth scroll to upload section
    $('a[href="#upload-section"]').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $('.card:first').offset().top - 20
        }, 500);
    });
    
    // Tooltips
    $('[title]').tooltip({
        trigger: 'hover',
        placement: 'top'
    });
});