jQuery(document).ready(function($) {
    // AJAX search (if needed)
    $('.ems-ajax-search').on('input', function() {
        var search = $(this).val();
        var project = $('select[name="emp_project"]').val();
        
        $.ajax({
            url: ems_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'ems_search',
                nonce: ems_frontend.nonce,
                search: search,
                project: project
            },
            success: function(response) {
                $('.ems-employees-list').html(response);
            }
        });
    });
    
    // Responsive table
    function makeTableResponsive() {
        if ($(window).width() < 768) {
            $('.ems-table thead').hide();
            $('.ems-table tbody tr').each(function() {
                $(this).find('td').each(function(i) {
                    var header = $('.ems-table th').eq(i).text();
                    $(this).attr('data-label', header);
                });
            });
        } else {
            $('.ems-table thead').show();
            $('.ems-table tbody tr td').removeAttr('data-label');
        }
    }
    
    makeTableResponsive();
    $(window).resize(makeTableResponsive);
});