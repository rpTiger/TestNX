<?php
class EMS_Admin_Interface {
    
    private $db;
    private $importer;
    private $page_hook;
    
    public function __construct($db, $importer) {
        $this->db = $db;
        $this->importer = $importer;
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'handle_form_submissions'));
        add_action('admin_notices', array($this, 'show_admin_notices'));
    }
    
    public function add_admin_menu() {
        $this->page_hook = add_menu_page(
            __('Employee Management', 'ems'),
            __('Employees', 'ems'),
            'manage_options',
            'employee-management',
            array($this, 'render_admin_page'),
            'dashicons-groups',
            30
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if ($hook !== $this->page_hook) {
            return;
        }
        
        // Enqueue Bootstrap CSS
        wp_enqueue_style(
            'bootstrap-css',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
            array(),
            '5.3.0'
        );
        
        // Enqueue Bootstrap Icons
        wp_enqueue_style(
            'bootstrap-icons',
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css',
            array(),
            '1.10.0'
        );
        
        // Enqueue DataTables CSS
        wp_enqueue_style(
            'datatables-css',
            'https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css',
            array('bootstrap-css'),
            '1.13.6'
        );
        
        // Enqueue Bootstrap JS
        wp_enqueue_script(
            'bootstrap-bundle',
            'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
            array(),
            '5.3.0',
            true
        );
        
        // Enqueue jQuery
        wp_enqueue_script('jquery');
        
        // Enqueue DataTables JS
        wp_enqueue_script(
            'datatables-js',
            'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js',
            array('jquery'),
            '1.13.6',
            true
        );
        
        wp_enqueue_script(
            'datatables-bootstrap-js',
            'https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js',
            array('datatables-js'),
            '1.13.6',
            true
        );
        
        // Custom admin styles
        wp_enqueue_style(
            'ems-admin-style',
            EMS_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            EMS_VERSION
        );
        
        // Custom admin scripts
        wp_enqueue_script(
            'ems-admin-script',
            EMS_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'datatables-bootstrap-js'),
            EMS_VERSION,
            true
        );
    }
    
    public function handle_form_submissions() {
        if (!isset($_POST['ems_action']) || !current_user_can('manage_options')) {
            return;
        }
        
        check_admin_referer('ems_import_nonce', 'ems_nonce');
        
        $action = sanitize_text_field($_POST['ems_action']);
        
        if ($action === 'import_csv' && isset($_FILES['csv_file'])) {
            $this->handle_csv_upload();
        }
        
        if ($action === 'download_sample') {
            $this->handle_sample_download();
        }
    }
    
    private function handle_csv_upload() {
        $file = $_FILES['csv_file'];
        
        $validation = $this->importer->validate_csv_file($file);
        
        if (!$validation['valid']) {
            set_transient('ems_admin_notice', array(
                'type' => 'error',
                'message' => $validation['message']
            ), 30);
            return;
        }
        
        // Move uploaded file
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['path'] . '/' . sanitize_file_name($file['name']);
        
        if (!move_uploaded_file($file['tmp_name'], $file_path)) {
            set_transient('ems_admin_notice', array(
                'type' => 'error',
                'message' => 'Failed to move uploaded file.'
            ), 30);
            return;
        }
        
        // Get delimiter from form
        $delimiter = ',';
        if (isset($_POST['delimiter'])) {
            $delimiter = $_POST['delimiter'];
            if ($delimiter === '\t') {
                $delimiter = "\t";
            }
        }
        
        // Import CSV (replaces all existing data)
        $result = $this->importer->import_csv_replace_all($file_path, array(
            'delimiter' => $delimiter
        ));
        
        // Clean up file
        @unlink($file_path);
        
        if (!$result['success']) {
            set_transient('ems_admin_notice', array(
                'type' => 'error',
                'message' => $result['message']
            ), 30);
            return;
        }
        
        // Prepare success message with better details
        $message = sprintf(
            '✅ Successfully processed %d rows. %d employees inserted into database.',
            $result['total_rows'],
            $result['actual_count']
        );
        
        // Check if skipped_rows exists before using it
        if (isset($result['skipped_rows']) && $result['skipped_rows'] > 0) {
            $message .= sprintf(' %d rows had minor issues but were imported with default values.', $result['skipped_rows']);
        }
        
        $notice = array(
            'type' => 'success',
            'message' => $message
        );
        
        // Check if errors exists before using it
        if (isset($result['errors']) && !empty($result['errors'])) {
            $notice['errors'] = array_slice($result['errors'], 0, 10); // Show only first 10 errors
        }
        
        set_transient('ems_admin_notice', $notice, 30);
    }
    
    private function handle_sample_download() {
        $sample = $this->importer->generate_sample_csv();
        
        if ($sample) {
            wp_redirect($sample['url']);
            exit;
        } else {
            set_transient('ems_admin_notice', array(
                'type' => 'error',
                'message' => 'Failed to generate sample CSV.'
            ), 30);
        }
    }
    
    public function show_admin_notices() {
        $notice = get_transient('ems_admin_notice');
        
        if ($notice) {
            $type = $notice['type'];
            $message = $notice['message'];
            
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible">';
            echo '<p>' . esc_html($message) . '</p>';
            
            if (isset($notice['errors']) && !empty($notice['errors'])) {
                echo '<div style="margin-top: 10px;">';
                echo '<p><strong>Import Notes (' . count($notice['errors']) . ' issues found):</strong></p>';
                echo '<ul>';
                foreach ($notice['errors'] as $error) {
                    echo '<li>' . esc_html($error) . '</li>';
                }
                if (count($notice['errors']) > 10) {
                    echo '<li>... and ' . (count($notice['errors']) - 10) . ' more similar issues</li>';
                }
                echo '</ul>';
                echo '</div>';
            }
            
            echo '</div>';
            
            delete_transient('ems_admin_notice');
        }
    }
    
    public function render_admin_page() {
        if (!$this->db->table_exists()) {
            $this->show_table_notice();
            return;
        }
        
        // Get all employees for DataTable
        $employees = $this->db->get_all_employees();
        $total_employees = $this->db->get_employee_count();
        $last_import = $this->db->get_latest_import_date();
        
        ?>
        <div class="wrap ems-admin-wrap">
            <h1 class="wp-heading-inline">Employee Management</h1>
            
            <!-- Quick Stats -->
            <div class="ems-stats">
                <div class="ems-stat-card">
                    <div class="ems-stat-icon">
                        <i class="bi bi-person-badge"></i>
                    </div>
                    <div class="ems-stat-content">
                        <div class="ems-stat-label">Total Employees</div>
                        <div class="ems-stat-value"><?php echo esc_html($total_employees); ?></div>
                    </div>
                </div>
                
                <div class="ems-stat-card">
                    <div class="ems-stat-icon">
                        <i class="bi bi-calendar-check"></i>
                    </div>
                    <div class="ems-stat-content">
                        <div class="ems-stat-label">Last Updated</div>
                        <div class="ems-stat-value">
                            <?php echo $last_import ? date('d M Y', strtotime($last_import)) : 'Never'; ?>
                        </div>
                    </div>
                </div>
                
                <div class="ems-stat-card">
                    <div class="ems-stat-icon">
                        <i class="bi bi-database"></i>
                    </div>
                    <div class="ems-stat-content">
                        <div class="ems-stat-label">Database Status</div>
                        <div class="ems-stat-value">Active</div>
                    </div>
                </div>
            </div>
            
            <!-- CSV Upload Section -->
            <div class="card ems-card">
                <div class="card-header">
                    <h3 class="card-title">Update Employee Data</h3>
                    <span class="badge badge-warning">Replaces All Data</span>
                </div>
                <div class="card-body">
                    <div class="alert alert-warning">
                        <strong>Important:</strong> Uploading a new CSV file will completely replace all existing employee data.
                    </div>
                    
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('ems_import_nonce', 'ems_nonce'); ?>
                        <input type="hidden" name="ems_action" value="import_csv">
                        
                        <div class="ems-form-row">
                            <div class="ems-form-column">
                                <label for="csv_file" class="form-label">
                                    CSV File Upload <span class="required">*</span>
                                </label>
                                <div class="file-upload-area">
                                    <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv" required>
                                    <div class="file-upload-content">
                                        <i class="bi bi-cloud-arrow-up"></i>
                                        <div>Drag & drop or click to upload</div>
                                        <small>Supports CSV files up to 10MB</small>
                                        <button type="button" class="button button-secondary" onclick="document.getElementById('csv_file').click()">
                                            Browse Files
                                        </button>
                                    </div>
                                    <div id="file-name" class="file-name-display"></div>
                                </div>
                            </div>
                            
                            <div class="ems-form-column">
                                <label for="delimiter" class="form-label">
                                    CSV Format Options
                                </label>
                                <select class="form-select" id="delimiter" name="delimiter">
                                    <option value="," selected>Comma Separated (,)</option>
                                    <option value=";">Semicolon (;)</option>
                                    <option value="\t">Tab Separated</option>
                                </select>
                                <div class="form-text">
                                    Select the delimiter used in your CSV file
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info mt-4">
                            <strong>Required CSV Format:</strong> 
                            <code>Sr No, Name, Designation, Date of Birth, Date of Joining, Date of Retirement, Grade, Project</code>
                            <div class="mt-2">
                                <small>Date format: YYYY-MM-DD (e.g., 2023-12-31)</small>
                            </div>
                        </div>
                        
                        <div class="ems-form-actions mt-4">
                            <button type="submit" class="button button-primary button-large">
                                Upload & Replace All Data
                            </button>
                            
                           <!--  <button type="submit" name="ems_action" value="download_sample" class="button button-secondary">
                                Download Sample CSV
                            </button> -->
                            
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=employee-management&action=export_csv'), 'export_csv'); ?>" 
                               class="button button-success">
                                Export Current Data
                            </a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Employee List Table -->
            <div class="card ems-card mt-4">
                <div class="card-header">
                    <h3 class="card-title">Employee Records</h3>
                    <span class="badge"><?php echo esc_html($total_employees); ?> employees</span>
                </div>
                <div class="card-body">
                    <?php if (empty($employees)): ?>
                        <div class="ems-empty-state">
                            <i class="bi bi-people"></i>
                            <h4>No Employee Records Found</h4>
                            <p>Upload a CSV file to populate employee data</p>
                            <a href="#upload-section" class="button button-primary">
                                Upload CSV File
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table id="employee-table" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>SR No</th>
                                        <th>Employee Name</th>
                                        <th>Designation</th>
                                        <th>Date of Birth</th>
                                        <th>Date of Joining</th>
                                        <th>Project</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($employees as $employee): ?>
                                        <tr>
                                            <td><?php echo esc_html($employee->sr_no); ?></td>
                                            <td>
                                                <div class="employee-name">
                                                    <?php echo esc_html($employee->name); ?>
                                                    <?php if ($employee->grade): ?>
                                                        <small class="text-muted"><?php echo esc_html($employee->grade); ?></small>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td><?php echo esc_html($employee->designation); ?></td>
                                            <td><?php echo date('d M Y', strtotime($employee->date_of_birth)); ?></td>
                                            <td><?php echo date('d M Y', strtotime($employee->date_of_joining)); ?></td>
                                            <td>
                                                <?php if ($employee->project): ?>
                                                    <?php echo esc_html($employee->project); ?>
                                                <?php else: ?>
                                                    <span class="text-muted">No Project</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <script>
        (function($) {
            'use strict';
            
            // File upload preview
            $('#csv_file').on('change', function(e) {
                if (this.files.length > 0) {
                    const fileName = this.files[0].name;
                    $('#file-name').html('<i class="bi bi-file-earmark-text me-1"></i>' + fileName).show();
                }
            });
            
            // Form validation
            $('form').on('submit', function(event) {
                const fileInput = document.getElementById('csv_file');
                
                if (fileInput.files.length > 0) {
                    const fileName = fileInput.files[0].name;
                    const fileExt = fileName.split('.').pop().toLowerCase();
                    
                    if (fileExt !== 'csv') {
                        alert('Please select a CSV file.');
                        event.preventDefault();
                        return;
                    }
                }
                
                if (!confirm('⚠️ IMPORTANT: This will DELETE ALL existing employee data and replace it with the CSV file.\n\nAre you sure you want to continue?')) {
                    event.preventDefault();
                    return;
                }
                
                // Show loading overlay
                const loadingOverlay = $('<div>').attr('id', 'ems-loading-overlay').css({
                    'position': 'fixed',
                    'top': 0,
                    'left': 0,
                    'right': 0,
                    'bottom': 0,
                    'background': 'rgba(255,255,255,0.95)',
                    'z-index': 9999,
                    'display': 'flex',
                    'justify-content': 'center',
                    'align-items': 'center'
                }).html(`
                    <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                    <div class="mt-4 text-center">
                        <h5>Processing CSV Import</h5>
                        <p class="text-muted">This may take a moment. Please wait...</p>
                    </div>
                `);
                
                $('body').append(loadingOverlay);
            });
            
            // Initialize DataTable
            if ($('#employee-table').length) {
                $('#employee-table').DataTable({
                    pageLength: 25,
                    lengthMenu: [10, 25, 50, 100],
                    order: [[0, 'asc']],
                    language: {
                        search: "Search employees:",
                        lengthMenu: "Show _MENU_ entries",
                        info: "Showing _START_ to _END_ of _TOTAL_ entries",
                        infoEmpty: "No records available",
                        infoFiltered: "(filtered from _MAX_ total entries)",
                        paginate: {
                            first: "First",
                            last: "Last",
                            next: "Next",
                            previous: "Previous"
                        }
                    },
                    columnDefs: [{
                        targets: '_all',
                        orderable: false
                    }],
                    dom: '<"top"f>rt<"bottom"lip><"clear">',
                    responsive: true,
                    ordering: false
                });
            }
            
        })(jQuery);
        </script>
        <?php
    }
    
    private function show_table_notice() {
        ?>
        <div class="notice notice-error">
            <p>Database table not found. Please deactivate and reactivate the plugin.</p>
        </div>
        <?php
    }
}