<?php
class EMS_CSV_Importer {
    
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function import_csv_replace_all($file_path, $options = array()) {
        
        error_log('EMS: ========== STARTING CSV IMPORT ==========');
        error_log('EMS: CSV file path: ' . $file_path);
        
        $defaults = array(
            'delimiter' => ',',
            'skip_first_row' => true
        );
        
        $options = wp_parse_args($options, $defaults);
        
        if (!file_exists($file_path)) {
            error_log('EMS: ERROR: CSV file not found');
            return array(
                'success' => false,
                'message' => 'CSV file not found',
                'imported' => 0
            );
        }
        
        // Truncate table first
        error_log('EMS: Truncating existing table...');
        $this->db->truncate_table();
        
        $handle = fopen($file_path, 'r');
        if ($handle === false) {
            error_log('EMS: ERROR: Cannot open CSV file');
            return array(
                'success' => false,
                'message' => 'Cannot open CSV file',
                'imported' => 0
            );
        }
        
        // Skip header row
        if ($options['skip_first_row']) {
            $headers = fgetcsv($handle, 0, $options['delimiter']);
            error_log('EMS: CSV Headers: ' . implode(', ', $headers));
        }
        
        $employees = array();
        $imported = 0;
        $errors = array();
        $row_num = $options['skip_first_row'] ? 1 : 0;
        $bad_rows = 0;
        
        error_log('EMS: Starting to process CSV rows...');
        
        while (($row = fgetcsv($handle, 0, $options['delimiter'])) !== false) {
            $row_num++;
            
            // Skip completely empty rows
            if (empty($row) || (count($row) == 1 && trim($row[0]) == '')) {
                continue;
            }
            
            // Process the row
            $employee_data = $this->process_csv_row($row, $row_num);
            
            if (isset($employee_data['error'])) {
                $errors[] = $employee_data['error'];
                $bad_rows++;
                
                // Log first 10 errors only
                if (count($errors) <= 10) {
                    error_log("EMS: Row $row_num error: " . $employee_data['error']);
                }
                
                // Try to insert anyway with default designation for missing data
                $fixed_data = $this->fix_missing_data($row, $row_num);
                if ($fixed_data) {
                    $employees[] = $fixed_data;
                    $imported++;
                    error_log("EMS: Row $row_num - Inserted with fixed data");
                }
                
                continue;
            }
            
            $employees[] = $employee_data;
            $imported++;
            
            // Insert in batches of 100
            if (count($employees) >= 100) {
                error_log("EMS: Inserting batch of " . count($employees) . " employees");
                $batch_result = $this->db->insert_batch_employees($employees);
                error_log("EMS: Batch inserted: $batch_result records");
                $employees = array(); // Reset for next batch
            }
        }
        
        fclose($handle);
        
        // Insert remaining employees
        if (!empty($employees)) {
            error_log("EMS: Inserting final batch of " . count($employees) . " employees");
            $batch_result = $this->db->insert_batch_employees($employees);
            error_log("EMS: Final batch inserted: $batch_result records");
        }
        
        error_log("EMS: ========== IMPORT COMPLETED ==========");
        error_log("EMS: Total rows processed: " . ($row_num - ($options['skip_first_row'] ? 1 : 0)));
        error_log("EMS: Successfully imported: $imported");
        error_log("EMS: Rows with errors: $bad_rows");
        error_log("EMS: Total errors found: " . count($errors));
        
        // Get actual count from database
        $actual_count = $this->db->get_employee_count();
        error_log("EMS: Database count after import: $actual_count");
        
        return array(
            'success' => true,
            'imported' => $imported,
            'errors' => $errors,
            'bad_rows' => $bad_rows,
            'actual_count' => $actual_count,
            'total_rows' => $row_num - ($options['skip_first_row'] ? 1 : 0)
        );
    }
    
    private function process_csv_row($row, $row_num) {
        
        // Clean row data - remove quotes and trim
        $row = array_map(function($value) {
            return trim($value, " \t\n\r\0\x0B\"'");
        }, $row);
        
        // Ensure we have at least 8 columns
        while (count($row) < 8) {
            $row[] = '';
        }
        
        // Map columns exactly as in CSV
        $sr_no = isset($row[0]) ? $row[0] : '';
        $name = isset($row[1]) ? $row[1] : '';
        $designation = isset($row[2]) ? $row[2] : '';
        $date_of_birth = isset($row[3]) ? $row[3] : '';
        $date_of_joining = isset($row[4]) ? $row[4] : '';
        $date_of_retirement = isset($row[5]) ? $row[5] : '';
        $grade = isset($row[6]) ? $row[6] : '';
        $project = isset($row[7]) ? $row[7] : '';
        
        // Check for missing designation but allow insertion anyway
        if (empty($designation)) {
            // Don't fail here - we'll fix it in fix_missing_data()
            return array('error' => "Row {$row_num}: Designation is empty");
        }
        
        // Validate required fields
        if (empty($sr_no)) {
            return array('error' => "Row {$row_num}: SR No is required");
        }
        
        if (!is_numeric($sr_no)) {
            return array('error' => "Row {$row_num}: SR No must be a number, got: '$sr_no'");
        }
        
        $sr_no = intval($sr_no);
        
        if (empty($name)) {
            return array('error' => "Row {$row_num}: Name is required");
        }
        
        if (empty($date_of_birth)) {
            return array('error' => "Row {$row_num}: Date of Birth is required");
        }
        
        if (empty($date_of_joining)) {
            return array('error' => "Row {$row_num}: Date of Joining is required");
        }
        
        // Format dates
        $date_of_birth = $this->format_date($date_of_birth);
        $date_of_joining = $this->format_date($date_of_joining);
        $date_of_retirement_formatted = !empty($date_of_retirement) ? $this->format_date($date_of_retirement) : null;
        
        if (!$date_of_birth) {
            return array('error' => "Row {$row_num}: Invalid Date of Birth: " . $row[3]);
        }
        
        if (!$date_of_joining) {
            return array('error' => "Row {$row_num}: Invalid Date of Joining: " . $row[4]);
        }
        
        if ($date_of_retirement_formatted === false) {
            return array('error' => "Row {$row_num}: Invalid Date of Retirement: " . $row[5]);
        }
        
        // Prepare employee data
        return array(
            'sr_no' => $sr_no,
            'name' => sanitize_text_field($name),
            'designation' => sanitize_text_field($designation),
            'date_of_birth' => $date_of_birth,
            'date_of_joining' => $date_of_joining,
            'date_of_retirement' => $date_of_retirement_formatted,
            'grade' => !empty($grade) ? sanitize_text_field($grade) : null,
            'project' => !empty($project) ? sanitize_text_field($project) : null
        );
    }
    
    private function fix_missing_data($row, $row_num) {
        // Try to fix rows with missing designation by inserting with default values
        
        // Clean row data
        $row = array_map(function($value) {
            return trim($value, " \t\n\r\0\x0B\"'");
        }, $row);
        
        // Ensure we have at least 8 columns
        while (count($row) < 8) {
            $row[] = '';
        }
        
        $sr_no = isset($row[0]) ? $row[0] : '';
        $name = isset($row[1]) ? $row[1] : '';
        $designation = isset($row[2]) ? $row[2] : '';
        $date_of_birth = isset($row[3]) ? $row[3] : '';
        $date_of_joining = isset($row[4]) ? $row[4] : '';
        $date_of_retirement = isset($row[5]) ? $row[5] : '';
        $grade = isset($row[6]) ? $row[6] : '';
        $project = isset($row[7]) ? $row[7] : '';
        
        // Check minimum requirements
        if (empty($sr_no) || !is_numeric($sr_no) || empty($name) || 
            empty($date_of_birth) || empty($date_of_joining)) {
            return false; // Can't fix this row
        }
        
        // Format dates
        $date_of_birth_formatted = $this->format_date($date_of_birth);
        $date_of_joining_formatted = $this->format_date($date_of_joining);
        $date_of_retirement_formatted = !empty($date_of_retirement) ? $this->format_date($date_of_retirement) : null;
        
        if (!$date_of_birth_formatted || !$date_of_joining_formatted) {
            return false; // Invalid dates
        }
        
        // Use default designation if empty
        if (empty($designation)) {
            $designation = 'Not Specified';
        }
        
        // Return fixed data
        return array(
            'sr_no' => intval($sr_no),
            'name' => sanitize_text_field($name),
            'designation' => sanitize_text_field($designation),
            'date_of_birth' => $date_of_birth_formatted,
            'date_of_joining' => $date_of_joining_formatted,
            'date_of_retirement' => $date_of_retirement_formatted,
            'grade' => !empty($grade) ? sanitize_text_field($grade) : null,
            'project' => !empty($project) ? sanitize_text_field($project) : null
        );
    }
    
    private function format_date($date_string) {
        if (empty($date_string)) {
            return null;
        }
        
        $date_string = trim($date_string);
        
        // Already in Y-m-d format
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_string)) {
            return $date_string;
        }
        
        // Try common formats
        $formats = array('d/m/Y', 'm/d/Y', 'd-m-Y', 'm-d-Y', 'Y/m/d', 'Y-m-d');
        
        foreach ($formats as $format) {
            $date = DateTime::createFromFormat($format, $date_string);
            if ($date && $date->format($format) === $date_string) {
                return $date->format('Y-m-d');
            }
        }
        
        // Try strtotime
        $timestamp = strtotime($date_string);
        if ($timestamp !== false) {
            return date('Y-m-d', $timestamp);
        }
        
        return false;
    }
    
    public function validate_csv_file($file) {
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
            return array('valid' => false, 'message' => 'File upload failed. Error code: ' . $file['error']);
        }
        
        // Check extension
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'csv') {
            return array('valid' => false, 'message' => 'File must be CSV format.');
        }
        
        return array('valid' => true, 'message' => '');
    }
}