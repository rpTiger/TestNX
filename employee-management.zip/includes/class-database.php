<?php
class EMS_Database {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . EMS_TABLE_NAME;
    }
    
    public function create_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id INT(11) NOT NULL AUTO_INCREMENT,
            sr_no INT(11) NOT NULL,
            name VARCHAR(255) NOT NULL,
            designation VARCHAR(255) NOT NULL,
            date_of_birth DATE NOT NULL,
            date_of_joining DATE NOT NULL,
            date_of_retirement DATE,
            grade VARCHAR(50),
            project VARCHAR(255),
            import_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY sr_no (sr_no),
            KEY idx_name (name),
            KEY idx_designation (designation),
            KEY idx_project (project),
            KEY idx_import_date (import_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add debugging
        error_log('EMS Database table created/checked: ' . $this->table_name);
    }
    
    public function truncate_table() {
        global $wpdb;
        error_log('EMS Truncating table: ' . $this->table_name);
        return $wpdb->query("TRUNCATE TABLE {$this->table_name}");
    }
    
    public function insert_batch_employees($employees) {
        global $wpdb;
        
        if (empty($employees)) {
            error_log('EMS: No employees to insert');
            return 0;
        }
        
        error_log('EMS: Starting batch insert with ' . count($employees) . ' employees');
        
        $inserted = 0;
        
        foreach ($employees as $employee) {
            // Insert one by one to avoid SQL errors
            $result = $wpdb->insert(
                $this->table_name,
                array(
                    'sr_no' => $employee['sr_no'],
                    'name' => $employee['name'],
                    'designation' => $employee['designation'],
                    'date_of_birth' => $employee['date_of_birth'],
                    'date_of_joining' => $employee['date_of_joining'],
                    'date_of_retirement' => $employee['date_of_retirement'],
                    'grade' => $employee['grade'],
                    'project' => $employee['project'],
                    'import_date' => current_time('mysql')
                ),
                array(
                    '%d',  // sr_no
                    '%s',  // name
                    '%s',  // designation
                    '%s',  // date_of_birth
                    '%s',  // date_of_joining
                    '%s',  // date_of_retirement
                    '%s',  // grade
                    '%s',  // project
                    '%s'   // import_date
                )
            );
            
            if ($result === false) {
                error_log('EMS: Failed to insert employee: ' . $wpdb->last_error);
                error_log('EMS: Employee data: ' . print_r($employee, true));
            } else {
                $inserted++;
            }
        }
        
        error_log('EMS: Successfully inserted ' . $inserted . ' employees');
        return $inserted;
    }
    
    public function get_all_employees() {
        global $wpdb;
        
        $results = $wpdb->get_results("SELECT * FROM {$this->table_name} ORDER BY sr_no ASC");
        
        error_log('EMS: Retrieved ' . count($results) . ' employees from database');
        
        return $results;
    }
    
    public function get_employee_count() {
        global $wpdb;
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        error_log('EMS: Total employee count: ' . $count);
        return $count;
    }
    
    public function get_latest_import_date() {
        global $wpdb;
        return $wpdb->get_var("SELECT MAX(import_date) FROM {$this->table_name}");
    }
    
    public function table_exists() {
        global $wpdb;
        $exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;
        error_log('EMS: Table exists check: ' . ($exists ? 'YES' : 'NO'));
        return $exists;
    }
    
    public function test_connection() {
        global $wpdb;
        
        error_log('EMS: Testing database connection');
        error_log('EMS: Table name: ' . $this->table_name);
        error_log('EMS: WordPress table prefix: ' . $wpdb->prefix);
        
        // Try to create table if doesn't exist
        if (!$this->table_exists()) {
            error_log('EMS: Table does not exist, creating...');
            $this->create_table();
        }
        
        return $this->table_exists();
    }
}