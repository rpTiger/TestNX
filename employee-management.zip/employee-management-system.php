<?php
/**
 * Plugin Name: Employee Management System
 * Plugin URI: https://yourwebsite.com/
 * Description: Manage employee data with CSV import that replaces old data automatically
 * Version: 1.2.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('EMS_VERSION', '1.2.0');
define('EMS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EMS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EMS_TABLE_NAME', 'ems_employees');

// Enable debugging
if (!defined('WP_DEBUG_LOG')) {
    define('WP_DEBUG_LOG', true);
}

// Include required files
require_once EMS_PLUGIN_DIR . 'includes/class-database.php';
require_once EMS_PLUGIN_DIR . 'includes/class-csv-importer.php';
require_once EMS_PLUGIN_DIR . 'includes/class-admin-interface.php';

// Initialize the plugin
class EmployeeManagementSystem {
    
    private static $instance = null;
    private $db;
    private $importer;
    private $admin;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init();
    }
    
    private function init() {
        // Initialize database
        $this->db = new EMS_Database();
        
        // Test database connection
        add_action('init', array($this, 'test_database'));
        
        // Initialize CSV importer
        $this->importer = new EMS_CSV_Importer($this->db);
        
        // Initialize admin interface
        if (is_admin()) {
            $this->admin = new EMS_Admin_Interface($this->db, $this->importer);
        }
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this->db, 'create_table'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Add export handler
        add_action('admin_init', array($this, 'handle_export'));
    }
    
    public function test_database() {
        // Test if we can connect to database
        if (is_admin() && current_user_can('manage_options')) {
            $this->db->test_connection();
        }
    }
    
    public function handle_export() {
        if (!isset($_GET['page']) || $_GET['page'] !== 'employee-management') {
            return;
        }
        
        if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
            check_admin_referer('export_csv');
            $this->export_csv();
        }
    }
    
    private function export_csv() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . EMS_TABLE_NAME;
        
        error_log('EMS: Starting CSV export from table: ' . $table_name);
        
        // Get all employees
        $employees = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY sr_no ASC");
        
        if (empty($employees)) {
            wp_die('No data to export');
        }
        
        error_log('EMS: Exporting ' . count($employees) . ' employees');
        
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=employees_' . date('Y-m-d') . '.csv');
        
        // Open output stream
        $output = fopen('php://output', 'w');
        
        // Add BOM for UTF-8
        fwrite($output, "\xEF\xBB\xBF");
        
        // Add headers
        fputcsv($output, array(
            'Sr No',
            'Name',
            'Designation',
            'Date of Birth',
            'Date of Joining',
            'Date of Retirement',
            'Grade',
            'Project'
        ));
        
        // Add data rows
        foreach ($employees as $employee) {
            fputcsv($output, array(
                $employee->sr_no,
                $employee->name,
                $employee->designation,
                $employee->date_of_birth,
                $employee->date_of_joining,
                $employee->date_of_retirement ?: '',
                $employee->grade ?: '',
                $employee->project ?: ''
            ));
        }
        
        fclose($output);
        exit;
    }
    
    public function deactivate() {
        // Cleanup if needed
    }
}

// Initialize the plugin
EmployeeManagementSystem::get_instance();

// Add direct database test function
function ems_test_database() {
    if (isset($_GET['ems_test_db']) && current_user_can('manage_options')) {
        global $wpdb;
        $table_name = $wpdb->prefix . EMS_TABLE_NAME;
        
        echo '<h2>EMS Database Test</h2>';
        
        // Check if table exists
        $exists = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") === $table_name;
        echo '<p>Table exists: ' . ($exists ? 'YES' : 'NO') . '</p>';
        
        if ($exists) {
            // Count records
            $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
            echo '<p>Total records: ' . $count . '</p>';
            
            // Show sample data
            $sample = $wpdb->get_results("SELECT * FROM {$table_name} LIMIT 5");
            echo '<pre>';
            print_r($sample);
            echo '</pre>';
        }
        
        // Show error if any
        echo '<p>Last error: ' . $wpdb->last_error . '</p>';
        
        die();
    }
}
add_action('init', 'ems_test_database');