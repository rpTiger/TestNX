<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Management Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard-card {
            transition: transform 0.3s;
            border-radius: 10px;
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        .stat-card {
            background: linear-gradient(to right, #4b6cb7, #182848);
            color: white;
        }
        .revenue-card {
            background: linear-gradient(to right, #56ab2f, #a8e063);
            color: white;
        }
        .instructor-card {
            background: linear-gradient(to right, #ff5e62, #ff9966);
            color: white;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            height: 100vh;
            position: fixed;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 15px 20px;
        }
        .sidebar .nav-link:hover {
            color: white;
            background-color: rgba(255, 255, 255, 0.1);
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .export-btn {
            margin-right: 10px;
        }
        .date-filter {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .progress {
            height: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar d-none d-md-block">
                <div class="text-center p-4">
                    <h4>Booking Dashboard</h4>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="#"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="bi bi-calendar-event me-2"></i> Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="bi bi-people me-2"></i> Instructors</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="bi bi-book me-2"></i> Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="bi bi-graph-up me-2"></i> Reports</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="bi bi-gear me-2"></i> Settings</a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Booking Management Dashboard</h2>
                    <div>
                        <button class="btn btn-success export-btn"><i class="bi bi-file-earmark-spreadsheet"></i> Export CSV</button>
                        <button class="btn btn-danger export-btn"><i class="bi bi-file-earmark-pdf"></i> Export PDF</button>
                    </div>
                </div>

                <!-- Date Filter -->
                <div class="date-filter">
                    <div class="row">
                        <div class="col-md-5">
                            <label for="startDate" class="form-label">Start Date</label>
                            <input type="date" class="form-control" id="startDate">
                        </div>
                        <div class="col-md-5">
                            <label for="endDate" class="form-label">End Date</label>
                            <input type="date" class="form-control" id="endDate">
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button class="btn btn-primary w-100">Apply Filter</button>
                        </div>
                    </div>
                </div>

                <!-- Summary Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card stat-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Total Booking Slots</h5>
                                        <h2 class="card-text">142</h2>
                                    </div>
                                    <div>
                                        <i class="bi bi-calendar-check" style="font-size: 2.5rem;"></i>
                                    </div>
                                </div>
                                <p class="card-text"><small>+12% from previous period</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card revenue-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Total Revenue</h5>
                                        <h2 class="card-text">$8,542</h2>
                                    </div>
                                    <div>
                                        <i class="bi bi-currency-dollar" style="font-size: 2.5rem;"></i>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <p class="card-text mb-0">Cash: $3,250</p>
                                        <p class="card-text">Online: $5,292</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card instructor-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Instructor Lessons</h5>
                                        <h2 class="card-text">87</h2>
                                    </div>
                                    <div>
                                        <i class="bi bi-person-check" style="font-size: 2.5rem;"></i>
                                    </div>
                                </div>
                                <p class="card-text"><small>Top instructor: John (24 lessons)</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card dashboard-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5 class="card-title">Course Subscriptions</h5>
                                        <h2 class="card-text">56</h2>
                                    </div>
                                    <div>
                                        <i class="bi bi-journal-bookmark" style="font-size: 2.5rem;"></i>
                                    </div>
                                </div>
                                <p class="card-text"><small>Most popular: Yoga Basics</small></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts and Detailed Data -->
                <div class="row">
                    <!-- Booking Slots Chart -->
                    <div class="col-md-6 mb-4">
                        <div class="card dashboard-card">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">Booking Slots Distribution</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="bookingChart" height="250"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Revenue Chart -->
                    <div class="col-md-6 mb-4">
                        <div class="card dashboard-card">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">Revenue Trends</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="revenueChart" height="250"></canvas>
                            </div>
                        </div>
                    </div>

                    <!-- Instructor Performance -->
                    <div class="col-md-6 mb-4">
                        <div class="card dashboard-card">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">Instructor Performance</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <h6>John <span class="float-end">24 lessons</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 85%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <h6>Sarah <span class="float-end">18 lessons</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-info" role="progressbar" style="width: 70%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <h6>Mike <span class="float-end">15 lessons</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 60%"></div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <h6>Emma <span class="float-end">12 lessons</span></h6>
                                    <div class="progress">
                                        <div class="progress-bar bg-primary" role="progressbar" style="width: 50%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Course Subscriptions -->
                    <div class="col-md-6 mb-4">
                        <div class="card dashboard-card">
                            <div class="card-header bg-white">
                                <h5 class="card-title mb-0">Course Subscription Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Course</th>
                                                <th>Subscriptions</th>
                                                <th>Revenue</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Yoga Basics</td>
                                                <td>24</td>
                                                <td>$2,880</td>
                                            </tr>
                                            <tr>
                                                <td>Advanced Fitness</td>
                                                <td>18</td>
                                                <td>$2,340</td>
                                            </tr>
                                            <tr>
                                                <td>Meditation</td>
                                                <td>15</td>
                                                <td>$1,500</td>
                                            </tr>
                                            <tr>
                                                <td>Swimming</td>
                                                <td>12</td>
                                                <td>$1,800</td>
                                            </tr>
                                            <tr>
                                                <td><strong>Total</strong></td>
                                                <td><strong>69</strong></td>
                                                <td><strong>$8,520</strong></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set default dates
            const today = new Date();
            const oneWeekAgo = new Date();
            oneWeekAgo.setDate(today.getDate() - 7);
            
            document.getElementById('startDate').valueAsDate = oneWeekAgo;
            document.getElementById('endDate').valueAsDate = today;

            // Booking Slots Chart
            const bookingCtx = document.getElementById('bookingChart').getContext('2d');
            const bookingChart = new Chart(bookingCtx, {
                type: 'bar',
                data: {
                    labels: ['Yoga', 'Fitness', 'Meditation', 'Swimming', 'Dance'],
                    datasets: [{
                        label: 'Booking Slots',
                        data: [42, 35, 28, 22, 15],
                        backgroundColor: [
                            'rgba(75, 108, 183, 0.7)',
                            'rgba(86, 171, 47, 0.7)',
                            'rgba(255, 94, 98, 0.7)',
                            'rgba(255, 153, 102, 0.7)',
                            'rgba(153, 102, 255, 0.7)'
                        ],
                        borderColor: [
                            'rgba(75, 108, 183, 1)',
                            'rgba(86, 171, 47, 1)',
                            'rgba(255, 94, 98, 1)',
                            'rgba(255, 153, 102, 1)',
                            'rgba(153, 102, 255, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Revenue Chart
            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            const revenueChart = new Chart(revenueCtx, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Revenue ($)',
                        data: [1200, 1900, 1500, 2100, 1800, 2500, 2200],
                        fill: false,
                        borderColor: 'rgb(86, 171, 47)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>