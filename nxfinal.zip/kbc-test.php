<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KBC Quiz Game</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            width: 100%;
            max-width: 900px;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .page {
            display: none;
            padding: 40px;
            position: relative;
        }
        
        .active {
            display: block;
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(30px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        h1 {
            color: #1a2a6c;
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.8rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        h2 {
            color: #b21f1f;
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.8rem;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #333;
            font-size: 1.1rem;
        }
        
        input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        input:focus {
            border-color: #1a2a6c;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 42, 108, 0.2);
        }
        
        .btn {
            display: block;
            width: 100%;
            padding: 18px;
            background: linear-gradient(to right, #1a2a6c, #b21f1f);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }
        
        .btn:active {
            transform: translateY(1px);
        }
        
        .btn::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
        }
        
        .btn:hover::after {
            left: 100%;
        }
        
        .question-container {
            background-color: #f8f9fa;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            animation: bounceIn 0.6s;
        }
        
        @keyframes bounceIn {
            0% { transform: scale(0.8); opacity: 0; }
            70% { transform: scale(1.02); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .question {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 25px;
            color: #333;
            line-height: 1.4;
        }
        
        .options {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .option {
            padding: 18px;
            background-color: white;
            border: 2px solid #ddd;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 16px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .option:hover {
            background-color: #f0f0f0;
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
        }
        
        .option.selected {
            background-color: #1a2a6c;
            color: white;
            border-color: #1a2a6c;
            transform: scale(1.02);
            box-shadow: 0 0 15px rgba(26, 42, 108, 0.5);
        }
        
        .option.correct {
            background-color: #28a745;
            color: white;
            border-color: #28a745;
            animation: celebrate 1s;
        }
        
        @keyframes celebrate {
            0% { transform: scale(1); }
            25% { transform: scale(1.1); }
            50% { transform: scale(1); }
            75% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .option.wrong {
            background-color: #dc3545;
            color: white;
            border-color: #dc3545;
            animation: sadShake 0.8s;
        }
        
        @keyframes sadShake {
            0% { transform: translateX(0); }
            20% { transform: translateX(-10px); }
            40% { transform: translateX(10px); }
            60% { transform: translateX(-10px); }
            80% { transform: translateX(10px); }
            100% { transform: translateX(0); }
        }
        
        .option.locked {
            cursor: not-allowed;
        }
        
        .navigation {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
        }
        
        .nav-btn {
            padding: 14px 30px;
            background: linear-gradient(to right, #1a2a6c, #b21f1f);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        
        .nav-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
        }
        
        .nav-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .progress-bar {
            height: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
            margin-bottom: 25px;
            overflow: hidden;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .progress {
            height: 100%;
            background: linear-gradient(to right, #1a2a6c, #b21f1f);
            width: 0%;
            transition: width 0.5s ease;
            position: relative;
            border-radius: 5px;
        }
        
        .progress::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            background-image: linear-gradient(
                -45deg, 
                rgba(255,255,255,0.2) 25%, 
                transparent 25%, 
                transparent 50%, 
                rgba(255,255,255,0.2) 50%, 
                rgba(255,255,255,0.2) 75%, 
                transparent 75%, 
                transparent
            );
            background-size: 30px 30px;
            animation: moveStripes 1s linear infinite;
        }
        
        @keyframes moveStripes {
            0% { background-position: 0 0; }
            100% { background-position: 30px 30px; }
        }
        
        .result-container {
            text-align: center;
            padding: 40px;
        }
        
        .score {
            font-size: 4rem;
            font-weight: 700;
            color: #1a2a6c;
            margin: 20px 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
            animation: scoreCountUp 1.5s;
        }
        
        @keyframes scoreCountUp {
            from { transform: scale(0.5); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        
        .message {
            font-size: 1.5rem;
            margin-bottom: 30px;
            color: #333;
        }
        
        .timer-container {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 70px;
            height: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            background: #1a2a6c;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }
        
        .timer {
            font-size: 1.8rem;
            font-weight: 700;
            color: #fff;
        }
        
        .timer.warning {
            color: #ff4d4d;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .question-number {
            position: absolute;
            top: 20px;
            left: 20px;
            background: #b21f1f;
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            font-size: 1.2rem;
        }
        
        .feedback {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px 40px;
            border-radius: 10px;
            font-size: 1.5rem;
            font-weight: bold;
            z-index: 100;
            display: none;
            animation: feedbackPop 0.5s;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
        }
        
        @keyframes feedbackPop {
            0% { transform: translate(-50%, -50%) scale(0.5); opacity: 0; }
            70% { transform: translate(-50%, -50%) scale(1.1); opacity: 1; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        
        .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background-color: #f00;
            animation: fall 5s linear infinite;
            z-index: -1;
        }
        
        @keyframes fall {
            0% { transform: translateY(-100px) rotate(0deg); opacity: 1; }
            100% { transform: translateY(100vh) rotate(360deg); opacity: 0; }
        }
        
        .celebration {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1000;
            display: none;
        }
        
        .celebration.active {
            display: block;
        }
        
        .celebration-item {
            position: absolute;
            font-size: 3rem;
            animation: celebrationFloat 2s ease-out forwards;
        }
        
        @keyframes celebrationFloat {
            0% { transform: translateY(100vh) scale(0); opacity: 0; }
            20% { opacity: 1; }
            80% { opacity: 1; }
            100% { transform: translateY(-100px) scale(1); opacity: 0; }
        }
        
        .sad-face {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 8rem;
            color: #dc3545;
            z-index: 1000;
            display: none;
            animation: sadFace 1.5s ease-out;
        }
        
        @keyframes sadFace {
            0% { transform: translate(-50%, -50%) scale(0); opacity: 0; }
            50% { transform: translate(-50%, -50%) scale(1.2); opacity: 1; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        
        .sad-face.active {
            display: block;
        }
        
        @media (max-width: 768px) {
            .options {
                grid-template-columns: 1fr;
            }
            
            h1 {
                font-size: 2.2rem;
            }
            
            .page {
                padding: 25px;
            }
            
            .timer-container, .question-number {
                position: relative;
                top: auto;
                left: auto;
                margin: 0 auto 20px;
                display: inline-block;
            }
            
            .question-number {
                margin-right: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Start Page -->
        <div id="start-page" class="page active">
            <h1><i class="fas fa-gamepad"></i> KBC Quiz Challenge</h1>
            <div class="form-group">
                <label for="name"><i class="fas fa-user"></i> Full Name</label>
                <input type="text" id="name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" id="email" placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="phone"><i class="fas fa-phone"></i> Phone Number</label>
                <input type="tel" id="phone" placeholder="Enter your phone number">
            </div>
            <button id="start-btn" class="btn">Start Game <i class="fas fa-play"></i></button>
        </div>
        
        <!-- Question Pages -->
        <div id="question-page-1" class="page">
            <div class="question-number">1</div>
            <div class="timer-container">
                <div class="timer">30</div>
            </div>
            <div class="progress-bar">
                <div class="progress" style="width: 20%"></div>
            </div>
            <h2>Question 1 of 5</h2>
            <div class="question-container">
                <div class="question">What is the capital of France?</div>
                <div class="options">
                    <div class="option" data-value="A">A) London</div>
                    <div class="option" data-value="B">B) Berlin</div>
                    <div class="option" data-value="C">C) Paris</div>
                    <div class="option" data-value="D">D) Madrid</div>
                </div>
            </div>
            <div class="navigation">
                <button class="nav-btn" disabled><i class="fas fa-arrow-left"></i> Previous</button>
                <button class="nav-btn next-btn">Next <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
        
        <div id="question-page-2" class="page">
            <div class="question-number">2</div>
            <div class="timer-container">
                <div class="timer">30</div>
            </div>
            <div class="progress-bar">
                <div class="progress" style="width: 40%"></div>
            </div>
            <h2>Question 2 of 5</h2>
            <div class="question-container">
                <div class="question">Which planet is known as the Red Planet?</div>
                <div class="options">
                    <div class="option" data-value="A">A) Venus</div>
                    <div class="option" data-value="B">B) Mars</div>
                    <div class="option" data-value="C">C) Jupiter</div>
                    <div class="option" data-value="D">D) Saturn</div>
                </div>
            </div>
            <div class="navigation">
                <button class="nav-btn prev-btn"><i class="fas fa-arrow-left"></i> Previous</button>
                <button class="nav-btn next-btn">Next <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
        
        <div id="question-page-3" class="page">
            <div class="question-number">3</div>
            <div class="timer-container">
                <div class="timer">30</div>
            </div>
            <div class="progress-bar">
                <div class="progress" style="width: 60%"></div>
            </div>
            <h2>Question 3 of 5</h2>
            <div class="question-container">
                <div class="question">What is the largest mammal in the world?</div>
                <div class="options">
                    <div class="option" data-value="A">A) Elephant</div>
                    <div class="option" data-value="B">B) Blue Whale</div>
                    <div class="option" data-value="C">C) Giraffe</div>
                    <div class="option" data-value="D">D) Polar Bear</div>
                </div>
            </div>
            <div class="navigation">
                <button class="nav-btn prev-btn"><i class="fas fa-arrow-left"></i> Previous</button>
                <button class="nav-btn next-btn">Next <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
        
        <div id="question-page-4" class="page">
            <div class="question-number">4</div>
            <div class="timer-container">
                <div class="timer">30</div>
            </div>
            <div class="progress-bar">
                <div class="progress" style="width: 80%"></div>
            </div>
            <h2>Question 4 of 5</h2>
            <div class="question-container">
                <div class="question">Who painted the Mona Lisa?</div>
                <div class="options">
                    <div class="option" data-value="A">A) Vincent van Gogh</div>
                    <div class="option" data-value="B">B) Pablo Picasso</div>
                    <div class="option" data-value="C">C) Leonardo da Vinci</div>
                    <div class="option" data-value="D">D) Michelangelo</div>
                </div>
            </div>
            <div class="navigation">
                <button class="nav-btn prev-btn"><i class="fas fa-arrow-left"></i> Previous</button>
                <button class="nav-btn next-btn">Next <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
        
        <div id="question-page-5" class="page">
            <div class="question-number">5</div>
            <div class="timer-container">
                <div class="timer">30</div>
            </div>
            <div class="progress-bar">
                <div class="progress" style="width: 100%"></div>
            </div>
            <h2>Question 5 of 5</h2>
            <div class="question-container">
                <div class="question">What is the chemical symbol for gold?</div>
                <div class="options">
                    <div class="option" data-value="A">A) Go</div>
                    <div class="option" data-value="B">B) Gd</div>
                    <div class="option" data-value="C">C) Au</div>
                    <div class="option" data-value="D">D) Ag</div>
                </div>
            </div>
            <div class="navigation">
                <button class="nav-btn prev-btn"><i class="fas fa-arrow-left"></i> Previous</button>
                <button class="nav-btn submit-btn">Submit <i class="fas fa-check"></i></button>
            </div>
        </div>
        
        <!-- Result Page -->
        <div id="result-page" class="page">
            <div class="result-container">
                <h1>Quiz Completed!</h1>
                <div class="message">Congratulations, <span id="player-name"></span>!</div>
                <div class="score">Your Score: <span id="score-value">0</span>/5</div>
                <div class="message" id="result-message"></div>
                <button id="restart-btn" class="btn">Play Again <i class="fas fa-redo"></i></button>
            </div>
        </div>
        
        <!-- Feedback Popup -->
        <div class="feedback" id="feedback"></div>
        
        <!-- Celebration Animation -->
        <div class="celebration" id="celebration"></div>
        
        <!-- Sad Face Animation -->
        <div class="sad-face" id="sad-face">😞</div>
    </div>

    <script>
        // Correct answers for each question
        const correctAnswers = {
            1: "C",
            2: "B",
            3: "B",
            4: "C",
            5: "C"
        };
        
        // User answers storage
        const userAnswers = {};
        
        // DOM elements
        const startPage = document.getElementById('start-page');
        const questionPages = [
            document.getElementById('question-page-1'),
            document.getElementById('question-page-2'),
            document.getElementById('question-page-3'),
            document.getElementById('question-page-4'),
            document.getElementById('question-page-5')
        ];
        const resultPage = document.getElementById('result-page');
        const feedback = document.getElementById('feedback');
        const celebration = document.getElementById('celebration');
        const sadFace = document.getElementById('sad-face');
        
        const startBtn = document.getElementById('start-btn');
        const nextBtns = document.querySelectorAll('.next-btn');
        const prevBtns = document.querySelectorAll('.prev-btn');
        const submitBtn = document.querySelector('.submit-btn');
        const restartBtn = document.getElementById('restart-btn');
        
        const playerName = document.getElementById('player-name');
        const scoreValue = document.getElementById('score-value');
        const resultMessage = document.getElementById('result-message');
        
        // Timers for each question
        let timers = [];
        let answerLocked = [false, false, false, false, false];
        
        // Event listeners
        startBtn.addEventListener('click', startGame);
        restartBtn.addEventListener('click', restartGame);
        
        // Add event listeners to next buttons
        nextBtns.forEach((btn, index) => {
            btn.addEventListener('click', () => navigateToQuestion(index + 1));
        });
        
        // Add event listeners to previous buttons
        prevBtns.forEach((btn, index) => {
            btn.addEventListener('click', () => navigateToQuestion(index));
        });
        
        submitBtn.addEventListener('click', showResults);
        
        // Add event listeners to options
        document.querySelectorAll('.option').forEach(option => {
            option.addEventListener('click', function() {
                const questionContainer = this.closest('.page');
                const questionId = Array.from(questionPages).indexOf(questionContainer) + 1;
                
                // Check if answer is already locked for this question
                if (answerLocked[questionId-1]) {
                    return;
                }
                
                // Lock the answer for this question
                answerLocked[questionId-1] = true;
                
                // Remove selected class from all options in this question
                const options = questionContainer.querySelectorAll('.option');
                options.forEach(opt => {
                    opt.classList.remove('selected');
                    opt.classList.add('locked');
                });
                
                // Add selected class to clicked option
                this.classList.add('selected');
                
                // Store user's answer
                userAnswers[questionId] = this.getAttribute('data-value');
                
                // Show immediate feedback with animations
                if (userAnswers[questionId] === correctAnswers[questionId]) {
                    this.classList.add('correct');
                    showFeedback("Correct! 🎉", "#28a745");
                    createCelebration();
                } else {
                    this.classList.add('wrong');
                    showFeedback("Wrong! 😞", "#dc3545");
                    showSadFace();
                    
                    // Highlight correct answer
                    options.forEach(opt => {
                        if (opt.getAttribute('data-value') === correctAnswers[questionId]) {
                            opt.classList.add('correct');
                        }
                    });
                }
            });
        });
        
        // Functions
        function startGame() {
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            
            if (!name || !email || !phone) {
                showFeedback("Please fill in all fields", "#dc3545");
                return;
            }
            
            // Store player name for result page
            playerName.textContent = name;
            
            // Hide start page and show first question
            startPage.classList.remove('active');
            questionPages[0].classList.add('active');
            
            // Start timers for each question
            startTimers();
        }
        
        function startTimers() {
            // Clear any existing timers
            timers.forEach(timer => clearInterval(timer));
            timers = [];
            
            // Set up timers for each question page
            questionPages.forEach((page, index) => {
                const timerElement = page.querySelector('.timer');
                let timeLeft = 30;
                
                const timer = setInterval(() => {
                    timeLeft--;
                    timerElement.textContent = timeLeft;
                    
                    // Add warning style when time is running out
                    if (timeLeft <= 10) {
                        timerElement.classList.add('warning');
                    }
                    
                    if (timeLeft <= 0) {
                        clearInterval(timer);
                        // Lock the answer if not already selected
                        if (!answerLocked[index]) {
                            answerLocked[index] = true;
                            const options = page.querySelectorAll('.option');
                            options.forEach(opt => {
                                opt.classList.add('locked');
                            });
                        }
                        
                        // Auto move to next question if time runs out
                        if (index < questionPages.length - 1) {
                            setTimeout(() => navigateToQuestion(index + 1), 1000);
                        } else {
                            setTimeout(showResults, 1000);
                        }
                    }
                }, 1000);
                
                timers.push(timer);
            });
        }
        
        function navigateToQuestion(questionIndex) {
            // Hide all question pages
            questionPages.forEach(page => page.classList.remove('active'));
            
            // Show the target question page
            questionPages[questionIndex].classList.add('active');
        }
        
        function showResults() {
            // Stop all timers
            timers.forEach(timer => clearInterval(timer));
            
            // Calculate score
            let score = 0;
            for (let i = 1; i <= 5; i++) {
                if (userAnswers[i] === correctAnswers[i]) {
                    score++;
                }
            }
            
            // Update result page
            scoreValue.textContent = score;
            
            // Set result message based on score
            if (score === 5) {
                resultMessage.textContent = "Perfect! You're a quiz master!";
                createCelebration();
            } else if (score >= 3) {
                resultMessage.textContent = "Good job! You know your stuff!";
            } else {
                resultMessage.textContent = "Better luck next time! Keep learning!";
            }
            
            // Hide question page and show result page
            questionPages[4].classList.remove('active');
            resultPage.classList.add('active');
        }
        
        function restartGame() {
            // Reset user answers
            for (let i = 1; i <= 5; i++) {
                delete userAnswers[i];
            }
            
            // Reset answer locks
            answerLocked = [false, false, false, false, false];
            
            // Clear selected options
            document.querySelectorAll('.option').forEach(option => {
                option.classList.remove('selected', 'correct', 'wrong', 'locked');
            });
            
            // Reset timers
            document.querySelectorAll('.timer').forEach(timer => {
                timer.textContent = '30';
                timer.classList.remove('warning');
            });
            
            // Hide animations
            celebration.classList.remove('active');
            sadFace.classList.remove('active');
            
            // Show start page and hide result page
            resultPage.classList.remove('active');
            startPage.classList.add('active');
            
            // Reset form
            document.getElementById('name').value = '';
            document.getElementById('email').value = '';
            document.getElementById('phone').value = '';
        }
        
        function showFeedback(message, color) {
            feedback.textContent = message;
            feedback.style.color = color;
            feedback.style.display = 'block';
            
            setTimeout(() => {
                feedback.style.display = 'none';
            }, 1500);
        }
        
        function createCelebration() {
            celebration.classList.add('active');
            celebration.innerHTML = '';
            
            const emojis = ['🎉', '🎊', '🥳', '👍', '👏', '⭐', '🏆', '💫'];
            
            for (let i = 0; i < 20; i++) {
                const item = document.createElement('div');
                item.className = 'celebration-item';
                item.textContent = emojis[Math.floor(Math.random() * emojis.length)];
                item.style.left = Math.random() * 100 + '%';
                item.style.animationDelay = Math.random() * 2 + 's';
                
                celebration.appendChild(item);
            }
            
            setTimeout(() => {
                celebration.classList.remove('active');
            }, 2000);
        }
        
        function showSadFace() {
            sadFace.classList.add('active');
            
            setTimeout(() => {
                sadFace.classList.remove('active');
            }, 1500);
        }
    </script>
</body>
</html>